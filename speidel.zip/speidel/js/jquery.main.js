$(document).ready(function(){
	initFixedHeader();
	initFixesSidebar();
	initMobileNav();
	initDropDownMenuMobile();
	initDropDownMenuMobileFooter();
	initFancyBox();
	initLightBox();
	initFullInputUserForm();
	initVerticalScroll();
	initSlickSlider();
	initSlickSlider2();
	initSlickSliderProduct();
	initTabs();
	initRange();
	initOpenFilter();
	initSpinner();
	initCustomSelect();
	initCheckboxTooltip();
	initAnchorOptionsTable();
	initShowMoreText();
});

function initFixedHeader() {
	window.onscroll = function() {myFunction()};
	var sticky = nav.offsetTop;
	function myFunction() {
		if (window.pageYOffset >= sticky) {
			$('#nav').addClass("sticky");
		} else {
			$('#nav').removeClass("sticky");
		}
	}
}
function initFixesSidebar() {
  $(".user-order .sidebar").stick_in_parent();
}
function initMobileNav(){
	$('.mob-btn').on('click', function(){
		$(this).closest('#nav').toggleClass('active');
		$('body').toggleClass('open-nav');
		return false;
	});
	$(document).click(function(event) {
		if ($(event.target).closest("#nav .nav-drop").length) return;
		$("#nav").removeClass('active');
		$('body').removeClass('open-nav');
		event.stopPropagation();
	});
};
function initDropDownMenuMobile(){
	var Accordion = function(el, multiple) {
		this.el = el || {};
		this.multiple = multiple || false;
		// Variables privadas
		var links = this.el.find('.arrow-down');
		// Evento
		links.on('click', {el: this.el, multiple: this.multiple}, this.dropdown)
	}
	Accordion.prototype.dropdown = function(e) {
		var $el = e.data.el;
			$this = $(this),
			$next = $this.next();
		$next.slideToggle();
		$this.parent().toggleClass('open');
		if (!e.data.multiple) {
			$el.find('.submenu-container').not($next).slideUp().parent().removeClass('open');
		};
	} 
	var accordion = new Accordion($('#dropdown-menu-mobile'), false);
};
function initDropDownMenuMobileFooter(){
	var Accordion = function(el, multiple) {
		this.el = el || {};
		this.multiple = multiple || false;
		// Variables privadas
		var links = this.el.find('.arrow-down');
		// Evento
		links.on('click', {el: this.el, multiple: this.multiple}, this.dropdown)
	}
	Accordion.prototype.dropdown = function(e) {
		var $el = e.data.el;
			$this = $(this),
			$next = $this.next();
		$next.slideToggle();
		$this.parent().toggleClass('open');
		if (!e.data.multiple) {
			$el.find('.nav-menu').not($next).slideUp().parent().removeClass('open');
		};
	} 
	var accordion = new Accordion($('#dropdown-menu-mobile-footer'), false);
};
function initFancyBox(){
	$('.fancybox').fancybox();
}
function initLightBox(){
	lightbox.option({
		'resizeDuration': 200,
		'wrapAround': true
	})
}
function initFullInputUserForm(){
	$('.user-form #name').on('keyup',function(){
		var $this = $(this),
			val = $this.val();
		if(val.length == ''){
			$('.user-form .user-name').removeClass('full-name');
		}else {
			$('.user-form .user-name').addClass('full-name');
		}
	});
	$('.user-form #password').on('keyup',function(){
		var $this = $(this),
			val = $this.val();
		if(val.length == ''){
			$('.user-form .user-password').removeClass('full-password');
		}else {
			$('.user-form .user-password').addClass('full-password');
		}
	});
	$('.user-form #email').on('keyup',function(){
		var $this = $(this),
			val = $this.val();
		if(val.length == ''){
			$('.user-form .user-email').removeClass('full-email');
		}else {
			$('.user-form .user-email').addClass('full-email');
		}
	});
	$('.user-form #tel').on('keyup',function(){
		var $this = $(this),
			val = $this.val();
		if(val.length == ''){
			$('.user-form .user-tel').removeClass('full-tel');
		}else {
			$('.user-form .user-tel').addClass('full-tel');
		}
	});
};
function initVerticalScroll() {
	$(".mCustomScrollbar").mCustomScrollbar({
		axis:"y",
		advanced:{autoExpandHorizontalScroll:false}
	});
}
function initSlickSlider() {
	$('.slider').slick({
		slidesToShow: 1,
		slidesToScroll: 1,
		arrows: true,
		dots: true,
		fade: true,
		responsive: [
			{
				breakpoint: 1024,
				settings: {
					adaptiveHeight: true
				}
			}
		]
	});
}
function initSlickSlider2() {
	$('.goods-list-slider').slick({
		slidesToShow: 5,
		slidesToScroll: 1,
		arrows: true,
		dots: false,
		responsive: [
			{
				breakpoint: 1200,
				settings: {
					slidesToShow: 4,
					slidesToScroll: 1
				}
			},
			{
				breakpoint: 1024,
				settings: {
					slidesToShow: 3,
					slidesToScroll: 1
				}
			},
			{
				breakpoint: 768,
				settings: {
					slidesToShow: 2,
					slidesToScroll: 1
				}
			},
			{
				breakpoint: 480,
				settings: {
					slidesToShow: 1,
					slidesToScroll: 1
				}
			}
		]
	});
}
function initSlickSliderProduct() {
	$('.slider-for').slick({
		slidesToShow: 1,
		slidesToScroll: 1,
		arrows: true,
		fade: true,
		adaptiveHeight: true,
		asNavFor: '.slider-nav'
	});
	$('.slider-nav').slick({
		slidesToShow: 5,
		slidesToScroll: 1,
		asNavFor: '.slider-for',
		arrows: true,
		dots: false,
		centerMode: true,
		focusOnSelect: true,
		responsive: [
			{
				breakpoint: 1200,
				settings: {
					slidesToShow: 4,
					slidesToScroll: 1
				}
			},
			{
				breakpoint: 1024,
				settings: {
					slidesToShow: 3,
					slidesToScroll: 1
				}
			},
			{
				breakpoint: 480,
				settings: {
					slidesToShow: 2,
					slidesToScroll: 1
				}
			}
		]
	});
}
function initTabs(){
	$('.tabset .tab-control').on('click', 'li:not(.active)', function() {
		$(this)
			.addClass('active').siblings().removeClass('active')
			.closest('.tabset').find('.tab').removeClass('active').eq($(this).index()).addClass('active');
			return false;
	});
	$('.tabset-catalog .tab-control-catalog').on('click', 'li:not(.active)', function() {
		$(this)
			.addClass('active').siblings().removeClass('active')
			.closest('.tabset-catalog').find('.tab').removeClass('active').eq($(this).index()).addClass('active');
			return false;
	});
	$('.tabset-delivery .tab-control-delivery').on('click', 'li:not(.active)', function() {
		$(this)
			.addClass('active').siblings().removeClass('active')
			.closest('.tabset-delivery').find('.tab').removeClass('active').eq($(this).index()).addClass('active');
			return false;
	});
}
function initRange(){
$("#slider-range").slider({
	min: 0,
	max: 15000,
	values: [5990,11990],
	range: true,
	stop: function(event, ui) {
		$("input#minCost").val($("#slider-range").slider("values",0));
		$("input#maxCost").val($("#slider-range").slider("values",1));
		},
		slide: function(event, ui){
		$("input#minCost").val($("#slider-range").slider("values",0));
		$("input#maxCost").val($("#slider-range").slider("values",1));
		}
});

$("input#minCost").change(function(){
	var value1=$("input#minCost").val();
	var value2=$("input#maxCost").val();
		if(parseInt(value1) > parseInt(value2)){
		value1 = value2;
		$("input#minCost").val(value1);
	}
	$("#slider-range").slider("values",0,value1);  
});
$("input#maxCost").change(function(){
	var value1=$("input#minCost").val();
	var value2=$("input#maxCost").val();
	if(parseInt(value1) > parseInt(value2)){
		value2 = value1;
		$("input#maxCost").val(value2);
	}
	$("#slider-range").slider("values",1,value2);
});
// фильтрация ввода в поля
	$('#slider-range input').keypress(function(event){
		var key, keyChar;
		if(!event) var event = window.event;
		if (event.keyCode) key = event.keyCode;
		else if(event.which) key = event.which;
		if(key==null || key==0 || key==8 || key==13 || key==9 || key==46 || key==37 || key==39 ) return true;
		keyChar=String.fromCharCode(key);
		if(!/\d/.test(keyChar)) return false;
	});
};
function initOpenFilter(){
	$('.expanded-opener').on('click', function() {
		$(this).closest('.filter-options-item').toggleClass('open-drop');
		$(this).siblings('.expanded').slideToggle();
		return false;
	});
	$('.open-filter').on('click', function(){
		$(this).toggleClass('open');
		$('.filter-options .filter-options-form').slideToggle('slow')
		return false;
	});
}
function initSpinner() {
	if ($('.spinner').length) {
		$('.spinner').spinner({
			min: 1,
		})
	}
}
function initCustomSelect(){
	$('.custom-select select').select2();
}
function initCheckboxTooltip(){
	$('input:checkbox').change(function(){
		if($(this).is(':checked')) 
			$(this).parent().addClass('selected'); 
		else 
			$(this).parent().removeClass('selected')
	});
}
function initAnchorOptionsTable(){
	$('.more-all-options').click(function(){
		$('body,html').animate({scrollTop:$('#full-options').offset().top + 'px'},2000);
		return false;
	});
}
function initShowMoreText(){
	$('.show-more').on('click', function() {
		$(this).siblings('.expanded').slideToggle().toggleClass('open-block');
		$(this).toggleClass('open');
		return false;
	});
	$('.more-goods').on('click', function() {
		$(this).siblings('.expanded').toggleClass('open-block');
		$(this).toggleClass('open');
		return false;
	});
}
/* AutoHeightBlocks */
function setEqualHeight(columns){
	var tallestcolumn = 0;
	columns.each( function(){
		currentHeight = $(this).height();
		if(currentHeight > tallestcolumn){
			tallestcolumn = currentHeight;
		}
	});
	columns.height(tallestcolumn);
}
setEqualHeight($(".news-list .news-text"));

/* YandexMap */
ymaps.ready(init); // карта соберется после загрузки скрипта и элементов
var myMap; // заглобалим переменную карты чтобы можно было ею вертеть из любого места
function init () { // функция - собиралка карты
	myMap = new ymaps.Map("map", { // создаем и присваиваем глобальной переменной карту и суем её в див с id="map"
			center: [55.3300, 37.3300], // тут центр
			behaviors: ['default', 'scrollZoom'], // скроллинг колесом
			zoom: 10 // тут масштаб
		});
	myMap.controls // добавим всяких кнопок, в скобках их позиции в блоке
		.add('zoomControl', { left: 5, top: 5 }) //Масштаб
		.add('typeSelector') //Список типов карты
		.add('mapTools', { left: 35, top: 5 }) // Стандартный набор кнопок
		.add('searchControl'); // Строка с поиском
	/* Создаем кастомные метки */
	myPlacemark0 = new ymaps.Placemark([55.3300,37.3300], { // Создаем метку с такими координатами
			balloonContent: '<div class="ballon"><p>Бутово, ЖК Бутово-Парк, 21<br> Аннино, Бульвар Дмитрия Донского</p><img class="close" onclick="myMap.balloon.close()" src="images/close.png"/></div>' // сдесь содержимое балуна в формате html, все стили в css
			}, {
			iconImageHref: 'images/icon-map.png', // картинка иконки
			iconImageSize: [60, 67], // размер иконки
			iconImageOffset: [-28, -60], // позиция иконки
			balloonContentSize: [270, 99], // размер нашего кастомного балуна в пикселях
			balloonLayout: "default#imageWithContent", // указываем что содержимое балуна кастомная
			balloonImageHref: '', // Картинка заднего фона балуна
			balloonImageOffset: [-65, -89], // смещание балуна, надо подогнать под стрелочку
			balloonImageSize: [260, 89], // размер картинки-бэкграунда балуна
			balloonShadow: false,
			balloonAutoPan: false // для фикса кривого выравнивания
			});
			/* тоже самое для других меток */
	myPlacemark1 = new ymaps.Placemark([55.3700,37.3700], {
			balloonContent: '<div class="ballon"><p>Бутово, Новое шоссе, 5<br> Бульвар Дмитрия Донского</p><img class="close" onclick="myMap.balloon.close()" src="images/close.png"/></div>'
			}, {
			iconImageHref: 'images/icon-map.png',
			iconImageSize: [60,67],
			iconImageOffset: [-28,-70],
			balloonContentSize: [270, 99],
			balloonLayout: "default#imageWithContent",
			balloonImageHref: '',
			balloonImageOffset: [-65, -89],
			balloonImageSize: [260, 89],
			balloonShadow: false,
			balloonAutoPan: false
			});
	/* Добавляем */
	myMap.geoObjects
		.add(myPlacemark0)
		.add(myPlacemark1);
	/* Фикс кривого выравнивания кастомных балунов */
	myMap.geoObjects.events.add([
		'balloonopen'
	], function (e) {
		var geoObject = e.get('target');
		myMap.panTo(geoObject.geometry.getCoordinates(), {
			delay: 0
		});
	});
}
/* end YandexMap */